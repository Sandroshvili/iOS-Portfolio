//
//  DetailWorker.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//

import UIKit
import Foundation

protocol DetailWorkerLogic {
    func fetchSimilarMovies(id: Int, completion: @escaping (SimilarMovies) -> Void)
}

class DetailWorker: DetailWorkerLogic {
    
    private let apiService: APIService
    
    init(apiService: APIService) {
        self.apiService = apiService
    }
    
    func fetchSimilarMovies(id: Int, completion: @escaping (SimilarMovies) -> Void) {
        apiService.fetchSimilarMovies(id: id) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let movies):
                    completion(movies)
                case .failure(let error):
                    print(error)
                }
            }
        }
    }
}
