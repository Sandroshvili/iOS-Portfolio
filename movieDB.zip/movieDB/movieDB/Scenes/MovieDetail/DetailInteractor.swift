//
//  DetailInteractor.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//

import Foundation
protocol DetailBusinessLogic {
    func process(request: DetailList.Request)
}
protocol DetailDataStore {
    var selectedMovie : Movie? { get set }
}

class DetailInteractor: DetailBusinessLogic, DetailDataStore {
    var similarMovies: [SimilarResults]?
    var selectedMovie : Movie?
    private let detailWorker: DetailWorker
    // MARK: Clean Components
    
    var presenter: DetailPresentationLogic?
    
    
    init(detailWorker: DetailWorker) {
        self.detailWorker = detailWorker
    }
    // MARK: - DetailBusinessLogic
    private func fetchMovies(for id: Int) {
        detailWorker.fetchSimilarMovies(id: id) { [self] 
            movies in
            self.similarMovies = movies.results
            presenter?.present(response: .fetchedMovies(movies: self.similarMovies!))
        }
    }
    
    func process(request: DetailList.Request) {
        switch request {
        case .viewDidLoad:
            fetchMovies(for: selectedMovie?.id ?? 0)
            presenter?.present(response: .fetchedMovie(movie: SimilarResults(name: selectedMovie!.name, voteAverage: selectedMovie!.voteAverage, posterPath: selectedMovie!.posterPath, overview: selectedMovie!.overview)))
        }
    }
}
