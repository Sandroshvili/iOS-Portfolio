//
//  DisplayMovies.swift
//  movieDB
//
//  Created by Sandroshvili on 10.12.20.
//

import Foundation
struct FetchMovies {
    struct DisplayMovie: Codable, CleanCellDataProvider {
        let name: String
        let voteAverage: Double
        let posterPath: String?
        let id: Int
        
        var identifier: String { SimilarMovieTableViewCell.identifier }
    }
    var displayedMovies: [DisplayMovie]
}
