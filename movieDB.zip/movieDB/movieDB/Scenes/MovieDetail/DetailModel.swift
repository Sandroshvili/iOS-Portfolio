//
//  DetailModel.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//

import UIKit

enum DetailList {
    
    // MARK: Interactor
    
    enum Request {
        case viewDidLoad
    }
    
    // MARK: Presenter
    
    enum Response {
        case fetchedMovies(movies: [SimilarResults])
        case fetchedMovie(movie: SimilarResults)
    }
    
    // MARK: ViewController
    
    enum ViewModel {
        case fetchedMovies(cellDataProviders: [CleanCellDataProvider])
        
        struct FetchMovies {
            struct DisplayedMovie: CleanCellDataProvider {
                
                let name: String
                let voteAverage: Double
                let overview: String
                let posterPath: String?
                
                var identifier: String { HeaderTableViewCell.identifier }
            }
            
            var displayedMovies: [DisplayedMovie]
        }
    }
}
