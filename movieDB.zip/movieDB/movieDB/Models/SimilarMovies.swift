//
//  RecommendationsAPI.swift
//  movieDB
//
//  Created by Sandroshvili on 15.11.20.
//

import Foundation

// MARK: - SimilarMovies
struct SimilarMovies: Codable {
    let results: [SimilarResults]
}

// MARK: - SimilarResults
struct SimilarResults: Codable {
    let name: String
    let voteAverage: Double
    let posterPath: String
    let overview: String
}


