//
//  SearchedMovies.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//

import Foundation

// MARK: - Response
struct SearchedMovies: Codable {
    let totalPages: Int
    let results: [SearchedMovie]
    let page: Int
}

// MARK: - Result
struct SearchedMovie: Codable {
    let name: String
    let voteAverage: Double
    let posterPath: String?
    let id: Int
}
