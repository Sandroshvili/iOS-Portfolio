//
//  ViewController.swift
//  movieDB
//
//  Created by TBC on 11/5/20.
//

import UIKit

protocol MoviesListDisplayLogic: class {
    func display(viewModel: MoviesList.ViewModel)
}

class MoviesListViewController: CleanViewController, MoviesListDisplayLogic, MovieDelegate {
    

    var movie : Movie?
    var interactor: MoviesListBusinessLogic?

    @IBOutlet private weak var tableView: UITableView!
    let apiService = APIService()
    var movies = [Movie]()
    var similarMovies = [SimilarResults]()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        setup()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.isNavigationBarHidden = true
    }

    override func setup() {
        let viewController = self
        let interactor = MoviesListInteractor()
        let presenter = MoviesListPresenter()
        let router = ListOrdersRouter()
        viewController.interactor = interactor
        viewController.router = router
        interactor.presenter = presenter
        presenter.viewController = viewController
        router.viewController = viewController
        router.dataStore = interactor
    }

    //TODO: - Display MovieList
    
    func display(viewModel: MoviesList.ViewModel) {
        <#code#>
    }
    
    func getMovie(movie: Movie) {
        self.movie = movie
        performSegue(withIdentifier: "DetailController", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let id = segue.identifier, id == "DetailController"{
            if let detailVC = segue.destination as? DetailViewController {
                detailVC.movie = self.movie
            }
        }
    }
    

}


//MARK: - TableView
extension MoviesListViewController: UITableViewDelegate, UITableViewDataSource {

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "HeaderCell", for: indexPath) as! HeaderTableViewCell
            
            return cell
        }

        let cell = tableView.dequeueReusableCell(withIdentifier: "CollectionCell", for: indexPath) as! CollectionTableViewCell
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 520
        }
        return 620
    }

    
}

