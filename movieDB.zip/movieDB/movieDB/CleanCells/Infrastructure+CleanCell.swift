//
//  Infrastructure.swift
//  movieDB
//
//  Created by Sandroshvili on 10.12.20.
//

import UIKit

// MARK: - UITableView

public extension UITableView {
    func register(types: [CleanTableViewCell.Type]) {
        types.forEach {
            register($0.nib, forCellReuseIdentifier: $0.identifier)
        }
    }
    
    func dequeueReusable(dataProvider: CleanCellDataProvider, for indexPath: IndexPath) -> CleanTableViewCell {
        dequeueReusableCell(withIdentifier: dataProvider.identifier, for: indexPath) as! CleanTableViewCell
    }
}

// MARK: - NSObject

public extension NSObject {
    var className: String {
        String(describing: type(of: self))
    }

    class var className: String {
        String(describing: self)
    }
}

// MARK: - CleanCellDataProvider

public protocol CleanCellDataProvider {
    var identifier: String { get }
}

// MARK: - CleanTableViewCell

public protocol CleanTableViewCell: UITableViewCell {
    static var nib: UINib { get }
    static var identifier: String { get }

    func setup(from model: CleanCellDataProvider, delegate: Any?)
}

public extension CleanTableViewCell {
    static var nib: UINib {
        UINib(nibName: className, bundle: Bundle(for: self))
    }

    static var identifier: String {
        className
    }
}
