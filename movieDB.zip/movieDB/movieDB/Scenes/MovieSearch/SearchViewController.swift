//
//  SearchViewController.swift
//  movieDB
//
//  Created by Sandroshvili on 11/5/20.
//

import UIKit

protocol SearchDisplayLogic: class {
    func display(viewModel: SearchedList.ViewModel)
    func reloadData()
}

class SearchViewController: CleanViewController, SearchDisplayLogic {
    
    var interactor: SearchBusinessLogic!
    var displayedMovies: [SearchedList.ViewModel.FetchMovies.SearchedMovie] = []
    
    var cleanCellDataProviders: [CleanCellDataProvider] = []
    
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var searchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.isNavigationBarHidden = false
        searchBar.delegate = self
        setupTableView()
        interactor.process(request: .viewDidLoad)
    }
    
    override func setup() {
        let viewController = self
        let interactor = SearchInteractor(searchWorker: SearchWorker(apiService: APIService()))
        let presenter = SearchPresenter()
        viewController.interactor = interactor
        interactor.presenter = presenter
        presenter.viewController = viewController
    }
    
    func display(viewModel: SearchedList.ViewModel) {
        switch viewModel {
        case .fetchedMovies(let displayedMovies):
            self.cleanCellDataProviders = displayedMovies
        }
    }
    
    func reloadData() {
            tableView.reloadData()
    }
    
    
    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
    }
    
}

extension SearchViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        cleanCellDataProviders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let dataProvider = cleanCellDataProviders[indexPath.row]
        let cell = tableView.dequeueReusable(dataProvider: dataProvider, for: indexPath)
        cell.setup(from: dataProvider, delegate: self)
        return cell
    }
}

extension SearchViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        interactor.process(request: .searchQuery(query: searchText))
    }
}
