//
//  RatingImageView.swift
//  movieDB
//
//  Created by Sandroshvili on 16.11.20.
//

import UIKit
import Foundation

class RatingImageView: UIImageView {
    func setRating(rating: Double) {
        self.image = UIImage(named: "rating_\(Int(round(rating)/2.0))")
    }
}
