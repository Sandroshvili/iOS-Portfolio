//
//  SearchModel.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//

import UIKit

enum SearchedList {
    
    // MARK: Interactor

    enum Request {
        case viewDidLoad
        case searchQuery(query: String)
    }
    
    // MARK: Presenter

    enum Response {
        case fetchedMovies(movies: [SearchedMovie])
    }
    
    // MARK: ViewController

    enum ViewModel {
        case fetchedMovies(cellDataProviders: [CleanCellDataProvider])
        
        struct FetchMovies {
            struct SearchedMovie: Codable, CleanCellDataProvider {
                let name: String
                let voteAverage: Double
                let posterPath: String?
                let id: Int
                
                var identifier: String { SimilarMovieTableViewCell.identifier }
            }
            var displayedMovies: [SearchedMovie]
        }
    }
}
