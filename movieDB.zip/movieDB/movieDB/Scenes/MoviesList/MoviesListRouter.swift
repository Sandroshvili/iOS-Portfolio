//
//  MoviesListRouter.swift
//  movieDB
//
//  Created by Sandroshvili on 23.11.20.
//
import UIKit
import Foundation

protocol MoviesListRoutingLogic {
    func navigate(to destination: ListOrdersRoutingDestination, animated: Bool)
}

enum ListOrdersRoutingDestination {
    case showDetails
}


protocol MovieListDataPassing {
    var dataStore: MovieListDataStore? { get set }
}

class MoviesListRouter: MoviesListRoutingLogic, MovieListDataPassing {

    var dataStore: MovieListDataStore?
    weak var viewController: MoviesListViewController?
    
    func navigate(to destination: ListOrdersRoutingDestination, animated: Bool) {
        switch destination {
        case .showDetails:
            routeToDetailVC()
        }
    }
    
    private func routeToDetailVC() {
        guard let detailVC = viewController?.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController else {
            return
        }
        detailVC.router.dataStore?.selectedMovie = dataStore?.selectedMovie
        viewController?.navigationController?.pushViewController(detailVC, animated: true)
    }
}
