//
//  DetailViewController.swift
//  movieDB
//
//  Created by Sandroshvili on 19.11.20.
//

import UIKit

protocol DetailDisplayLogic: class {
    func display(viewModel: DetailList.ViewModel)
    func reloadData()
}

class DetailViewController: CleanViewController, DetailDisplayLogic {
    
    // MARK: Clean Components
    var interactor: DetailBusinessLogic!
    var router: (DetailRoutingLogic & DetailDataPassing)!
    
    // MARK: Fields
    
    var cleanCellDataProviders: [CleanCellDataProvider] = []
    
    @IBOutlet private weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.isNavigationBarHidden = false
        setupTableView()
        interactor.process(request: .viewDidLoad)
    }
    
    override func setup() {
        let viewController = self
        let interactor = DetailInteractor(detailWorker: DetailWorker(apiService: APIService()))
        let presenter = DetailPresenter()
        let router = DetailRouter()
        viewController.interactor = interactor
        viewController.router = router
        interactor.presenter = presenter
        presenter.viewController = viewController
        router.viewController = viewController
        router.dataStore = interactor
    }
    
    //MARK: - Display MovieList
    
    func display(viewModel: DetailList.ViewModel) {
        switch viewModel {
        case .fetchedMovies(let displayedMovies):
            self.cleanCellDataProviders.append(contentsOf: displayedMovies)
        }
    }
    
    func reloadData() {
        tableView.reloadData()
    }
    
    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
    }
}

extension DetailViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        cleanCellDataProviders.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let dataProvider = cleanCellDataProviders[indexPath.row]
        let cell = tableView.dequeueReusable(dataProvider: dataProvider, for: indexPath)
        cell.setup(from: dataProvider, delegate: self)
        return cell
    }
}
