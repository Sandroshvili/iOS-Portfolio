//
//  TabBarController.swift
//  movieDB
//
//  Created by Sandroshvili on 11/5/20.
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        self.tabBar.backgroundColor = UIColor(named: "tab_bar_background")
        self.tabBar.tintColor = UIColor(named: "orange")
        self.tabBar.unselectedItemTintColor = UIColor(named: "gray")
    }

}
