//
//  APIModel.swift
//  movieDB
//
//  Created by Sandroshvili on 15.11.20.
//

import Foundation
import UIKit
// MARK: - MovieData
struct MovieData: Codable {
    let results: [Movie]
}

// MARK: - Result
struct Movie: Codable {
    let originalName: String
    let genreIds: [Int]
    let name: String
    let id: Int
    let voteAverage: Double
    let overview, posterPath: String
}

enum OriginCountry: String, Codable {
    case gb = "GB"
    case us = "US"
}

enum OriginalLanguage: String, Codable {
    case en = "en"
}


