//
//  SimilarMovieTableViewCell.swift
//  movieDB
//
//  Created by Sandroshvili on 19.11.20.
//

import UIKit

public class SimilarMovieTableViewCell: UITableViewCell {
    // MARK: - Outlets
    
    @IBOutlet private weak var movieImageView: UIImageView!
    @IBOutlet private weak var movieTitle: UILabel!
    @IBOutlet private weak var movieRatingImageView: RatingImageView!

    
    // MARK: - Lifecycle
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        movieImageView.layer.cornerRadius = 15
    }
    public override func prepareForReuse() {
        super.prepareForReuse()
        movieImageView.image = nil
    }
}

// MARK: - CleanTableViewCell

extension SimilarMovieTableViewCell: CleanTableViewCell {
    public func setup(from model: CleanCellDataProvider, delegate: Any?) {
        
        guard let model = model as? FetchMovies.DisplayMovie else { return }
        
        movieTitle.text = model.name
        movieRatingImageView.setRating(rating: model.voteAverage)
        if let poster = model.posterPath {
            poster
                .downloadImage { image in
                    DispatchQueue.main.async {
                        switch image {
                        case .success(let image):
                            self.movieImageView.image = image
                        case .failure(let error):
                            print(error)
                        }
                    }
                }
        }
    }
}
