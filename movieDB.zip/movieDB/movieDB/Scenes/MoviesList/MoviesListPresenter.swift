//
//  MoviesListPresenter.swift
//  movieDB
//
//  Created by Sandroshvili on 23.11.20.
//

import Foundation
protocol MoviesListPresentationLogic {
    func present(response: MoviesList.Response)
}

class MoviesListPresenter: MoviesListPresentationLogic {
    
    weak var viewController: MoviesListDisplayLogic?
    
    func present(response: MoviesList.Response) {
        switch response {
        case .fetchedMovies(let movies):
            let headerMovie = movies[0]
            let header: CleanCellDataProvider = MoviesList.ViewModel.FetchMovies.DisplayedMovie(name: headerMovie.name, id: headerMovie.id, voteAverage: headerMovie.voteAverage, overview: headerMovie.overview, posterPath: headerMovie.posterPath)
            let collectionMovies = movies.map { movie in
                return MoviesList.ViewModel.FetchMovies.PosterMovie.CollectionMovie(posterPath: movie.posterPath, id: movie.id)
            }
            let displayedMovies: CleanCellDataProvider = MoviesList.ViewModel.FetchMovies.PosterMovie(collectionMovies: collectionMovies)
            viewController?.display(viewModel: .fetchedMovies(cellDataProviders: [header] + [displayedMovies]))
            viewController?.reloadData()
        }
    }
}

