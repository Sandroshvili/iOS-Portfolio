//
//  CollectionTableViewCell.swift
//  movieDB
//
//  Created by Sandroshvili on 18.11.20.
//

import UIKit

class CollectionTableViewCell: UITableViewCell {
    var delegate: MovieDelegate?
    var displayedMovies: [MoviesList.ViewModel.FetchMovies.PosterMovie.CollectionMovie] = []
    var cleanCellDataProviders: [CleanCellDataProvider] = []
    
    @IBOutlet private weak var moviesCollectionView: UICollectionView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupCollectionView()
    }
    private func reloadData() {
            moviesCollectionView.reloadData()
    }
    
    private func setupCollectionView() {
        moviesCollectionView.delegate = self
        moviesCollectionView.dataSource = self
    }
}

extension CollectionTableViewCell: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.getMovie(movie: displayedMovies[indexPath.row])
    }
}

extension CollectionTableViewCell: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return displayedMovies.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCollectionViewCell", for: indexPath) as! MovieCollectionViewCell
        let displayedMovie = displayedMovies[indexPath.row]
        cell.setup(with: displayedMovie)
        return cell
    }
}

extension CollectionTableViewCell: CleanTableViewCell {
    func setup(from model: CleanCellDataProvider, delegate: Any?) {
        guard let model = model as? MoviesList.ViewModel.FetchMovies.PosterMovie else { return }
        displayedMovies.append(contentsOf: model.collectionMovies)
        reloadData()
        self.delegate = delegate as? MovieDelegate
    }
}
