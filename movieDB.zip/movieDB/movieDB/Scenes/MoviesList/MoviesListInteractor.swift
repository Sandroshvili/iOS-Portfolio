//
//  MoviesListInteractor.swift
//  movieDB
//
//  Created by Sandroshvili on 23.11.20.
//

import Foundation


protocol MoviesListBusinessLogic {
    func process(request: MoviesList.Request)
}

protocol MovieListDataStore {
    var selectedMovie: Movie? { get }
}

class MoviesListInteractor: MoviesListBusinessLogic, MovieListDataStore {
    var selectedMovie: Movie?
    private var movies = [Movie]()
    private let movieListWorker: MovieListWorker
    
    init(movieListWorker: MovieListWorker) {
        self.movieListWorker = movieListWorker
    }
    
    // MARK: Clean Components
    var presenter: MoviesListPresentationLogic?
    
    // MARK: - MovieListBusinessLogic
    private func fetchMovies(with page: Int) {
        movieListWorker.fetchMovies(with: page) { [weak self] result in
            self?.movies.append(contentsOf: result.results)
            self?.presenter?.present(response: .fetchedMovies(movies: self!.movies))
        }
    }
    
    private func selectMovie(at id: Int) {
        self.selectedMovie = self.movies.first(where: {
            $0.id == id
        })
    }
    
    func process(request: MoviesList.Request) {
        switch request {
        case .selectMovie(let id):
            selectMovie(at: id)
        case .refreshList(let page):
            fetchMovies(with: page)
        case .viewDidLoad:
            fetchMovies(with: 1)
        }
    }
}
