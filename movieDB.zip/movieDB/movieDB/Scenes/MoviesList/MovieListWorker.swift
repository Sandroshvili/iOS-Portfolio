import UIKit
import Foundation

protocol MoviesWorker {
    func fetchMovies(with page: Int, completion: @escaping (MovieData) -> Void)
}

class MovieListWorker: MoviesWorker {
    
    private let apiService: APIService
    
    init(apiService: APIService) {
        self.apiService = apiService
    }
    
    func fetchMovies(with page: Int, completion: @escaping (MovieData) -> Void) {
        apiService.fetchMovies(with: page) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let movies):
                    completion(movies)
                case .failure(let error):
                    print(error)
                }
            }
        }
    }
}

protocol MovieStoreProtocol
{
    // MARK: CRUD operations - Optional error
    func fetchMovies(completionHandler: @escaping (() throws -> [MovieData]) -> Void)
}
