//
//  ViewController.swift
//  movieDB
//
//  Created by Sandroshvili on 11/5/20.
//
import Foundation
import UIKit

protocol MoviesListDisplayLogic: class {
    func display(viewModel: MoviesList.ViewModel)
    func reloadData()
}

class MoviesListViewController: CleanViewController, MoviesListDisplayLogic, MovieDelegate {
    
    var currentPage = 1
    var interactor: MoviesListBusinessLogic!
    var router: (MoviesListRoutingLogic)?
    var cleanCellDataProviders: [CleanCellDataProvider] = []
    
    @IBOutlet private weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        interactor.process(request: .viewDidLoad)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.isNavigationBarHidden = true
    }
    
    override func setup() {
        let viewController = self
        let interactor = MoviesListInteractor(movieListWorker: MovieListWorker(apiService: APIService()))
        let presenter = MoviesListPresenter()
        let router = MoviesListRouter()
        viewController.interactor = interactor
        viewController.router = router
        interactor.presenter = presenter
        presenter.viewController = viewController
        router.viewController = viewController
        router.dataStore = interactor
    }
    
    //TODO: - Display MovieList
    
    func display(viewModel: MoviesList.ViewModel) {
        switch viewModel {
        case .fetchedMovies(let displayedMovies):
            self.cleanCellDataProviders = displayedMovies
        }
    }
    
    func reloadData() {
        tableView.reloadData()
    }
    
    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    //MARK: - Routing
    
    func getMovie(movie: MoviesList.ViewModel.FetchMovies.PosterMovie.CollectionMovie) {
        
        interactor.process(request: .selectMovie(id: movie.id))
        router?.navigate(to: .showDetails, animated: true)
    }
}

//MARK: - TableView
extension MoviesListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cleanCellDataProviders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let dataProvider = cleanCellDataProviders[indexPath.row]
        let cell = tableView.dequeueReusable(dataProvider: dataProvider, for: indexPath)
        cell.setup(from: dataProvider, delegate: self)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 600
        }
        return 620
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

