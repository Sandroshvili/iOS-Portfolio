//
//  SearchPresenter.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//

import Foundation
protocol SearchPresentationLogic {
    func present(response: SearchedList.Response)
}

class SearchPresenter: SearchPresentationLogic {
    
    weak var viewController: SearchDisplayLogic?
    
    func present(response: SearchedList.Response) {
        switch response {
        case .fetchedMovies(let movies):
            let displayedMovies: [CleanCellDataProvider] = movies.map {
                movie in
                return FetchMovies.DisplayMovie(name: movie.name, voteAverage: movie.voteAverage, posterPath: movie.posterPath, id: movie.id)
            }
            viewController?.display(viewModel: .fetchedMovies(cellDataProviders: displayedMovies))
            viewController?.reloadData()
        }
    }
}
