//
//  MoviesAPI.swift
//  movieDB
//
//  Created by Sandroshvili on 15.11.20.
//

import Foundation

class APIService {
    
    private let apiPrefix = "https://api.themoviedb.org/3/"
    private let apiKey = "0a100049bf7ca31ed79fe4b462cf2d88"
    
    func fetchMovies(with page: Int,completion: @escaping (Result<MovieData, NetworkError>) -> Void) {
      guard let url = URL(string: "\(apiPrefix)tv/popular?api_key=\(apiKey)&language=en-US&page=\(page)") else {
        completion(.failure(.invalidURL))
        return
      }
      URLSession.shared.dataTask(with: url) { (data, res, err) in
        guard let data = data else {return}
        do {
          let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
          let movies = try decoder.decode(MovieData.self, from: data)
            completion(.success(movies))
        } catch {
        }
      }.resume()
    }
    
    func fetchSimilarMovies(id: Int, completion: @escaping (Result<SimilarMovies, NetworkError>) -> Void) {
      guard let url = URL(string: "\(apiPrefix)tv/\(id)/similar?api_key=\(apiKey)&language=en-US&page=1") else {
        completion(.failure(.invalidURL))
        return
      }
      URLSession.shared.dataTask(with: url) { (data, res, err) in
        guard let data = data else {return}
        do {
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
          let movies = try decoder.decode(SimilarMovies.self, from: data)
            completion(.success(movies))
        } catch {
          print(error.localizedDescription)
        }
      }.resume()
    }
    
    func fetchSearchedMovies(searchText: String, completion: @escaping (Result<SearchedMovies, NetworkError>) -> Void) {
      guard let url = URL(string: "\(apiPrefix)search/tv?api_key=\(apiKey)&language=en-US&page=1&query=\(searchText)&include_adult=false") else {
        completion(.failure(.invalidURL))
        return
      }
      URLSession.shared.dataTask(with: url) { (data, res, err) in
        guard let data = data else {return}
        do {
          let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
          let movies = try decoder.decode(SearchedMovies.self, from: data)
            completion(.success(movies))
        } catch {
          print(error.localizedDescription)
        }
      }.resume()
    }
}
