//
//  DetailPresenter.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//````

import Foundation
protocol DetailPresentationLogic {
    func present(response: DetailList.Response)
}

class DetailPresenter: DetailPresentationLogic {
    weak var viewController: DetailDisplayLogic?
    
    func present(response: DetailList.Response) {
        switch response {
        case .fetchedMovie(let movie):
            let displayedMovie: CleanCellDataProvider = MoviesList.ViewModel.FetchMovies.DisplayedMovie(name: movie.name, id: 10, voteAverage: movie.voteAverage, overview: movie.overview, posterPath: movie.posterPath)
            viewController?.display(viewModel: .fetchedMovies(cellDataProviders: [displayedMovie]))
        case .fetchedMovies(let movies):
            let displayedMovies: [CleanCellDataProvider] = movies.map {
                movie in
                return FetchMovies.DisplayMovie(name: movie.name, voteAverage: movie.voteAverage, posterPath: movie.posterPath, id: 10)
            }
            viewController?.display(viewModel: .fetchedMovies(cellDataProviders: displayedMovies))
            viewController?.reloadData()
        }
    }
}
