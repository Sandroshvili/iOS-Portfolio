//
//  DetailRouter.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//

import Foundation
protocol DetailRoutingLogic {
}

protocol DetailDataPassing {
    var dataStore: DetailDataStore? { get set }
}

class DetailRouter: DetailDataPassing, DetailRoutingLogic {
    
    var dataStore: DetailDataStore?
    weak var viewController: DetailViewController?

}
