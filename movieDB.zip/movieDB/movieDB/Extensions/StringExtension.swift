//
//  StringExtension.swift
//  movieDB
//
//  Created by Sandroshvili on 18.11.20.
//

import UIKit
extension String {
    
    func downloadImage(completion: @escaping (Result<UIImage?, NetworkError>) -> Void) {
        guard let url = URL(string: "https://image.tmdb.org/t/p/w500" + self) else {return}
        URLSession.shared.dataTask(with: url) { (data, res, err) in
            guard let data = data else {return}
            completion(.success(UIImage(data: data)))
            completion(.failure(.invalidURL))
        }.resume()
    }
}
