//
//  SearchInteractor.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//

import Foundation

protocol SearchBusinessLogic {
    func process(request: SearchedList.Request)
}

class SearchInteractor: SearchBusinessLogic {
    // MARK: Clean Components
    var searchedMovies: [SearchedMovie]?
    var presenter: SearchPresentationLogic?
    private let searchWorker: SearchWorker
    
    init(searchWorker: SearchWorker) {
        self.searchWorker = searchWorker
    }
    
    // MARK: - SearchBusinessLogic
    func process(request: SearchedList.Request) {
        switch request {
        case .viewDidLoad:
            fetchMovies(for: "")
        case .searchQuery(let query):
            fetchMovies(for: query)
        }
    }
    
    private func fetchMovies(for string: String) {
        if string == "" {
            print("No Query Entered")
        } else {
            searchWorker.fetchSearchedMovies(searchText: string) { [self]
                movies in
                self.searchedMovies = movies.results
                presenter?.present(response: .fetchedMovies(movies: self.searchedMovies!))
            }
        }
    }
}
