//
//  NetworkError.swift
//  movieDB
//
//  Created by Sandroshvili on 30.11.20.
//

import Foundation

enum NetworkError: String, Error {
    case invalidURL = "This is invalid URL"
}
