//
//  MoviesListModels.swift
//  movieDB
//
//  Created by Sandroshvili on 23.11.20.
//

import UIKit

enum MoviesList {
    
    // MARK: Interactor

    enum Request {
        case viewDidLoad
        case refreshList(page: Int)
        case selectMovie(id: Int)
    }
    
    // MARK: Presenter

    enum Response {
        case fetchedMovies(movies: [Movie])
    }
    
    // MARK: ViewController

    enum ViewModel {
        case fetchedMovies(cellDataProviders: [CleanCellDataProvider])
        
        struct FetchMovies {
            struct DisplayedMovie: CleanCellDataProvider {
                let name: String
                let id: Int
                let voteAverage: Double
                let overview, posterPath: String
                
                var identifier: String { HeaderTableViewCell.identifier }
            }
            
            struct PosterMovie: CleanCellDataProvider {
                var collectionMovies: [CollectionMovie]
                
                struct CollectionMovie {
                    let posterPath: String
                    let id: Int
                }
                
                var identifier: String { CollectionTableViewCell.identifier }
            }

            var displayedMovies: [DisplayedMovie]
        }
    }
}
