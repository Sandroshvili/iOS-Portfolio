//
//  MovieCollectionViewCell.swift
//  movieDB
//
//  Created by Sandroshvili on 18.11.20.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet private weak var movieImageView: UIImageView!
    
    static var identifier: String  = "MovieCollectionViewCell"

    
    override func awakeFromNib() {
        super.awakeFromNib()
        movieImageView.layer.cornerRadius = 15
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        movieImageView.image = nil
    }
    
    func setup(with movie:MoviesList.ViewModel.FetchMovies.PosterMovie.CollectionMovie) {
        movie.posterPath
            .downloadImage { (image) in
                DispatchQueue.main.async {
                    switch image {
                    case .success(let image):
                        self.movieImageView.image = image
                    case .failure(let error):
                        print(error)
                    }
                }
            }
    }
}
