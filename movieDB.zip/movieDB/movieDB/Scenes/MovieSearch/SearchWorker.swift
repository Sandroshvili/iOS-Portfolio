//
//  SearchWorker.swift
//  movieDB
//
//  Created by Sandroshvili on 24.11.20.
//

import Foundation
import UIKit

protocol SearchWorkerLogic {
    func fetchSearchedMovies(searchText: String, completion: @escaping (SearchedMovies) -> Void)
}

class SearchWorker: SearchWorkerLogic {
    
    private let apiService: APIService
    
    init(apiService: APIService) {
        self.apiService = apiService
    }
    
    func fetchSearchedMovies(searchText: String, completion: @escaping (SearchedMovies) -> Void) {
        apiService.fetchSearchedMovies(searchText: searchText) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let movies):
                    completion(movies)
                case .failure(let error):
                    print(error)
                }
            }
        }
    }
}
