//
//  MovieDelegate.swift
//  movieDB
//
//  Created by Sandroshvili on 18.11.20.
//

import Foundation

protocol MovieDelegate {
    func getMovie(movie: MoviesList.ViewModel.FetchMovies.PosterMovie.CollectionMovie)
}
