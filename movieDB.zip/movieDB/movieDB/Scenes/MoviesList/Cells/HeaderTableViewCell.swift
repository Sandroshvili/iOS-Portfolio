//
//  HeaderTableViewCell.swift
//  movieDB
//
//  Created by Sandroshvili on 16.11.20.
//

import UIKit

class HeaderTableViewCell: UITableViewCell {
    //MARK: - Outlets
    @IBOutlet private weak var posterImageView: UIImageView!
    @IBOutlet private weak var ratingLabel: UILabel!
    @IBOutlet private weak var ratingImageView: RatingImageView!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var titleLabel: UILabel!
}

extension HeaderTableViewCell: CleanTableViewCell {
    public func setup(from model: CleanCellDataProvider, delegate: Any?) {

        guard let model = model as? MoviesList.ViewModel.FetchMovies.DisplayedMovie else { return }
        
        titleLabel.text = model.name
        model.posterPath
            .downloadImage { image in
                DispatchQueue.main.async {
                    switch image {
                    case .success(let image):
                        self.posterImageView.image = image
                    case .failure(let error):
                        print(error)
                    }
                }
            }
        ratingImageView.setRating(rating: model.voteAverage)
        descriptionLabel.text = model.overview
        ratingLabel.text = "\(model.voteAverage)"
    }
}
